Water Purification + Hot Bath compatibility datapack
Minecraft Java 1.21.1 / NeoForge

Install this ZIP in <world>/datapacks/ and run /reload.

- Disables the six Thirst Was Taken smelting recipes for water bottles, water buckets, and terracotta water bowls using NeoForge's false recipe condition.
- Leaves Thirst Was Taken's original campfire-cooking purification recipes untouched, so their intended purity progression remains intact and no duplicate campfire recipes are introduced.
- Restores hotbath:hot_water_bucket as a normal smelting recipe by overriding Hot Bath's conditional recipe.
- No campfire recipe for hotbath:hot_water_bucket is added.

This targets the recipe IDs in Thirst Was Taken 2.1.5 and Hot Bath 4.1.0. It changes recipes only, not purification mechanics implemented in code.
